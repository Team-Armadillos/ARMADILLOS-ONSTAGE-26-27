# ================= IMPORTS =================
from pybricks.hubs import PrimeHub
from pybricks.pupdevices import Motor, ColorSensor
from pybricks.parameters import Port
from pybricks.tools import wait
from pybricks.parameters import Color

# ================= HUB =================
hub = PrimeHub()

# ================= MOTORES =================
motorA = Motor(Port.A)
motorB = Motor(Port.B)
motorC = Motor(Port.C)
motorD = Motor(Port.D)

# ================= SENSOR =================
# ================= SENSOR =================

sensor_cor = ColorSensor(Port.E)

sensorE = ColorSensor(Port.E)
sensorF = ColorSensor(Port.F)

# ================= CONFIGURAÇÕES =================
WHEEL_DIAMETER_CM = 4.8
PI = 3.1416
DEGREES_PER_CM = 360 / (PI * WHEEL_DIAMETER_CM)

KP = 1.0
KI = 0.0
KD = 0.2

BASE_SPEED = 300
MAX_CORRECAO = 150

RAMP_UP_DIST = 7 * DEGREES_PER_CM
RAMP_DOWN_DIST = 12 * DEGREES_PER_CM

# ================= LINE FOLLOW =================
TARGET = 45

KP_LINE = 9
KD_LINE = 5.5

LINE_SPEED = 260
MAX_TURN = 800

# ================= PID =================
class PID:
    def __init__(self, kp, ki, kd):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.erro_anterior = 0
        self.integral = 0

    def calcular(self, erro):
        self.integral += erro
        derivada = erro - self.erro_anterior
        self.erro_anterior = erro

        saida = (self.kp * erro) + (self.ki * self.integral) + (self.kd * derivada)

        if saida > MAX_CORRECAO:
            saida = MAX_CORRECAO
        elif saida < -MAX_CORRECAO:
            saida = -MAX_CORRECAO

        return saida

# ================= BASE =================
def reset_motores():
    motorA.reset_angle(0)
    motorB.reset_angle(0)
    motorC.reset_angle(0)
    motorD.reset_angle(0)

def media_posicao():
    return (
        abs(motorA.angle()) +
        abs(motorB.angle()) +
        abs(motorC.angle()) +
        abs(motorD.angle())
    ) / 4

def aplicar_velocidade(motor, velocidade):
    velocidade = int(velocidade)
    if abs(velocidade) < 10:
        velocidade = 0
    motor.run(velocidade)

# ================= SENSOR =================
def viu_preto():
    return sensor_cor.reflection() < 35

# ================= RAMPA =================
def calcular_rampa(progresso, alvo, usar_desaceleracao):

    x = min(progresso / RAMP_UP_DIST, 1) if RAMP_UP_DIST > 0 else 1

    fator = 0.3 + (0.55 * (progresso ** 0.5))

    if progresso < RAMP_UP_DIST:
        fator = 0.35 + (x * x) * 0.5

    if usar_desaceleracao and alvo is not None:
        restante = alvo - progresso

        if restante < RAMP_DOWN_DIST:
            x2 = max(restante / RAMP_DOWN_DIST, 0) if RAMP_DOWN_DIST > 0 else 0
            desac = 0.25 + (x2 * x2) * 0.5
            fator = min(fator, desac)

    fator = max(0.25, min(fator, 0.85))
    return fator

# ================= MOVIMENTO =================
def mover(vA, vB, vC, vD, distancia_cm=None, velocidade=1, parar_no_preto=False):

    reset_motores()

    alvo_dist = None
    if distancia_cm is not None:
        alvo_dist = distancia_cm * DEGREES_PER_CM

    pid = PID(KP, KI, KD)

    hub.imu.reset_heading(0)
    wait(50)

    alvo_yaw = 0

    erro_filtrado = 0
    ALPHA = 0.6

    while True:

        progresso = media_posicao()

        if alvo_dist is not None and progresso >= alvo_dist:
            break

        if parar_no_preto and viu_preto():
            break

        fator_rampa = calcular_rampa(
            progresso,
            alvo_dist,
            usar_desaceleracao=not parar_no_preto
        )

        yaw = hub.imu.heading()
        erro = alvo_yaw - yaw

        erro_filtrado = (ALPHA * erro_filtrado) + ((1 - ALPHA) * erro)

        correcao = pid.calcular(erro_filtrado)

        base = BASE_SPEED * velocidade * fator_rampa

        sA = (vA * base) - correcao
        sB = (vB * base) + correcao
        sC = (vC * base) - correcao
        sD = (vD * base) + correcao

        aplicar_velocidade(motorA, sA)
        aplicar_velocidade(motorB, sB)
        aplicar_velocidade(motorC, sC)
        aplicar_velocidade(motorD, sD)

        wait(5)

    motorA.stop()
    motorB.stop()
    motorC.stop()
    motorD.stop()

# ================= SEGUIDOR DE LINHA =================
def seguir_linha(cm=None, vel=1, parar_vermelho=False):

    reset_motores()

    alvo = None

    if cm is not None:
        alvo = cm * DEGREES_PER_CM

    erro_anterior = 0

    while True:

        # ================= CONDIÇÃO DE PARADA =================

        # PARADA POR DISTÂNCIA
        if alvo is not None and media_posicao() >= alvo:
            break

        # PARADA POR VERMELHO NOS DOIS SENSORES
        if parar_vermelho:
            if sensorE.color() == Color.RED and sensorF.color() == Color.RED:
                break

        # ================= SENSOR =================

        leitura = sensor_cor.reflection()

        erro = leitura - TARGET

        # ================= PD =================

        proporcional = erro * KP_LINE

        derivada = (erro - erro_anterior) * KD_LINE

        correcao = proporcional + derivada

        erro_anterior = erro

        # ================= LIMITADOR =================

        if correcao > MAX_TURN:
            correcao = MAX_TURN

        elif correcao < -MAX_TURN:
            correcao = -MAX_TURN

        # ================= VELOCIDADE =================

        base = LINE_SPEED * vel

        curva = abs(erro) * 3

        velocidade = base - curva

        if velocidade < 120:
            velocidade = 120

        esquerda = velocidade - correcao
        direita = velocidade + correcao

        # ================= MOTORES =================

        motorA.run(-esquerda)
        motorB.run(direita)

        motorC.run(-esquerda)
        motorD.run(direita)

        wait(5)

    motorA.stop()
    motorB.stop()
    motorC.stop()
    motorD.stop()

# ================= GIRO =================
# ================= GIRO =================
def parar_motores():
    motorA.stop()
    motorB.stop()
    motorC.stop()
    motorD.stop()


def girar_direita(graus, vel=1):

    hub.imu.reset_heading(0)
    wait(200)

    while True:

        yaw = hub.imu.heading()

        erro = graus - abs(yaw)

        # ===== PARADA =====
        if erro <= 1:
            break

        # ===== DESACELERAÇÃO =====
        vmax = BASE_SPEED * vel
        vmin = 90

        fator = erro / graus

        if fator > 1:
            fator = 1

        velocidade = (vmax * fator)

        # ===== VELOCIDADE MÍNIMA =====
        if velocidade < vmin:
            velocidade = vmin

        # ===== GIRO DIREITA =====
        motorA.run(-velocidade)
        motorB.run(-velocidade)
        motorC.run(-velocidade)
        motorD.run(-velocidade)

        wait(10)

    parar_motores()


def girar_esquerda(graus, vel=1):

    hub.imu.reset_heading(0)
    wait(200)

    while True:

        yaw = hub.imu.heading()

        erro = graus - abs(yaw)

        # ===== PARADA =====
        if erro <= 1:
            break

        # ===== DESACELERAÇÃO =====
        vmax = BASE_SPEED * vel
        vmin = 90

        fator = erro / graus

        if fator > 1:
            fator = 1

        velocidade = (vmax * fator)

        # ===== VELOCIDADE MÍNIMA =====
        if velocidade < vmin:
            velocidade = vmin

        # ===== GIRO ESQUERDA =====
        motorA.run(velocidade)
        motorB.run(velocidade)
        motorC.run(velocidade)
        motorD.run(velocidade)

        wait(10)

    parar_motores()

# ================= MOVIMENTOS =================
def frente(cm=None, vel=1, preto=False):
    mover(-1, 1, -1, 1, cm, vel, preto)

def tras(cm=None, vel=1, preto=False):
    mover(1, -1, 1, -1, cm, vel, preto)

def esquerda(cm=None, vel=1, preto=False):
    mover(1, 1, -1, -1, cm, vel, preto)

def direita(cm=None, vel=1, preto=False):
    mover(-1, -1, 1, 1, cm, vel, preto)

def diag_frente_direita(cm=None, vel=1, preto=False):
    mover(-1, 0, 0, 1, cm, vel, preto)

# ================= MAIN =================
def main():

    seguir_linha(None, 1.3, parar_vermelho=True)
    #frente(70, 1.5)
    #girar_direita(90, 4)

main()

